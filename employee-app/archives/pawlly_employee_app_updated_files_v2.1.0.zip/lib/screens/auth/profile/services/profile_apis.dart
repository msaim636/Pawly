import 'package:nb_utils/nb_utils.dart';

import '../../../../models/base_response_model.dart';
import '../../../../network/network_utils.dart';
import '../../../../utils/api_end_points.dart';
import '../../../home/model/one_day_service_price_res.dart';

class ProfileApis {
  /// Get One Day Service Price
  static Future<OneDayServicePriceRes> getOneDayServicePrice() async {
    return OneDayServicePriceRes.fromJson(await handleResponse(await buildHttpResponse(APIEndPoints.getOneDayServicePrice, method: HttpMethodType.GET)));
  }

  /// Save One Day Service Price
  static Future<BaseResponseModel> saveOneDayServicePrice({required Map request}) async {
    return BaseResponseModel.fromJson(await handleResponse(await buildHttpResponse(
      APIEndPoints.saveOneDayServicePrice,
      request: request,
      method: HttpMethodType.POST,
    )));
  }
}
