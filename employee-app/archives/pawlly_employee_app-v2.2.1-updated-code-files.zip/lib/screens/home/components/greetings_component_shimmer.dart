import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly_employee/components/circle_widget.dart';
import 'package:pawlly_employee/components/shimmer_widget.dart';
import 'package:pawlly_employee/utils/app_common.dart';
import 'package:pawlly_employee/utils/colors.dart';

class GreetingsComponentShimmer extends StatelessWidget {
  const GreetingsComponentShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        ShimmerWidget(
          baseColor: isDarkMode.value ? shimmerDarkBaseColor : shimmerPrimaryBaseColor,
          padding: const EdgeInsets.symmetric(horizontal: 108, vertical: 8),
        ),
        ShimmerWidget(
          baseColor: isDarkMode.value ? shimmerDarkBaseColor : shimmerLightBaseColor,
          child: const CircleWidget(height: 26, width: 26),
        )
      ],
    ).paddingSymmetric(horizontal: 16, vertical: 16);
  }
}
