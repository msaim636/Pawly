import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../../components/app_scaffold.dart';
import '../../../components/loader_widget.dart';
import '../../../components/search_booking_widget.dart';
import '../../../main.dart';
import '../../../utils/empty_error_state_widget.dart';
import '../model/bookings_model.dart';
import 'bookings_card.dart';
import 'bookings_controller.dart';

class BookingSearchScreen extends StatelessWidget {
  BookingSearchScreen({super.key});

  final BookingsController bookingsController = BookingsController();

  @override
  Widget build(BuildContext context) {
    try {
      bookingsController.page(1);
      bookingsController.getBookingList(showloader: false);
    } catch (e) {
      debugPrint('handleSearch E: $e');
    }
    return AppScaffold(
      appBartitleText: locale.value.searchBookings,
      isLoading: bookingsController.isLoading,
      body: SizedBox(
        height: Get.height,
        child: SingleChildScrollView(
          child: Obx(
            () => Column(
              children: [
                8.height,
                SearchBookingWidget(
                  bookingsController: bookingsController,
                  onFieldSubmitted: (p0) {
                    bookingsController.isLoading(true);
                    bookingsController.isSearchText(bookingsController.searchCont.text.trim().isNotEmpty);
                    bookingsController.page(1);
                    bookingsController.getBookingList();
                  },
                ).paddingSymmetric(horizontal: 16),
                16.height,
                SnapHelperWidget<List<BookingDataModel>>(
                  future: bookingsController.getBookingsFuture.value,
                  errorBuilder: (error) {
                    return NoDataWidget(
                      title: error,
                      retryText: locale.value.reload,
                      imageWidget: const ErrorStateWidget(),
                      onRetry: () {
                        bookingsController.page(1);
                        bookingsController.isLoading(true);
                        bookingsController.getBookingList();
                      },
                    );
                  },
                  loadingWidget: const LoaderWidget(),
                  onSuccess: (bookingList) {
                    return AnimatedListView(
                      shrinkWrap: true,
                      itemCount: bookingList.length,
                      /*  physics: const AlwaysScrollableScrollPhysics(),*/
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      emptyWidget: NoDataWidget(
                        title: locale.value.noBookingsFound,
                        imageWidget: const EmptyStateWidget(),
                        subTitle: locale.value.thereAreCurrentlyNo,
                        retryText: locale.value.reload,
                        onRetry: () {
                          bookingsController.page(1);
                          bookingsController.isLoading(true);
                          bookingsController.getBookingList();
                        },
                      ).paddingSymmetric(horizontal: 16),
                      itemBuilder: (context, index) {
                        return BookingsCard(
                          booking: bookingList[index],
                          onUpdateBooking: () {
                            bookingList.removeAt(index);
                          },
                        );
                      },
                      onNextPage: () {
                        if (!bookingsController.isLastPage.value) {
                          bookingsController.page(bookingsController.page.value + 1);
                          bookingsController.getBookingList();
                        }
                      },
                      onSwipeRefresh: () async {
                        bookingsController.page(1);
                        bookingsController.getBookingList(showloader: false);
                        return await Future.delayed(const Duration(seconds: 2));
                      },
                    );
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
