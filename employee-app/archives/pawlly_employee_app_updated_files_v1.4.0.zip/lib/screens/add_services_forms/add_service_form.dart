import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly_employee/components/app_scaffold.dart';
import 'package:pawlly_employee/main.dart';
import 'package:pawlly_employee/screens/add_services_forms/add_service_controller.dart';
import 'package:pawlly_employee/utils/app_common.dart';

import '../../components/app_primary_widget.dart';
import '../../components/bottom_selection_widget.dart';
import '../../components/cached_image_widget.dart';
import '../../components/chat_gpt_loder.dart';
import '../../configs.dart';
import '../../utils/colors.dart';
import '../../utils/common_base.dart';
import '../../utils/constants.dart';
import 'model/category_model.dart';

class AddServiceForm extends StatelessWidget {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final ScrollController scrollController = ScrollController();

  final AddServiceController vetServiceController = Get.put(AddServiceController());

  final bool isEdit;

  AddServiceForm({super.key, this.isEdit = false});

  @override
  Widget build(BuildContext context) {
    log('vetServiceController.serviceImage.value.isNotEmpty ==> ${vetServiceController.serviceImage.value}');
    return AppScaffold(
      appBartitleText: isEdit ? 'Edit Service' : 'Add Service', //TODO: string
      isLoading: vetServiceController.isLoading,
      body: AnimatedScrollView(
        controller: scrollController,
        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 60, top: 16),
        children: [
          Form(
            key: formKey,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Service Image', style: boldTextStyle(size: 16)), //TODO: string
                12.height,
                Obx(
                  () => vetServiceController.imageFile.value.path.isNotEmpty || vetServiceController.serviceImage.value.isNotEmpty
                      ? Center(
                          child: Stack(
                            clipBehavior: Clip.none,
                            alignment: Alignment.center,
                            children: [
                              SizedBox(
                                width: 110,
                                height: 110,
                                child: Loader(),
                              ).visible(vetServiceController.serviceImage.value.isNotEmpty || vetServiceController.imageFile.value.path.isNotEmpty),
                              CachedImageWidget(
                                url: vetServiceController.imageFile.value.path.isNotEmpty ? vetServiceController.imageFile.value.path : vetServiceController.serviceImage.value,
                                height: 110,
                                width: 110,
                                fit: BoxFit.cover,
                              ).cornerRadiusWithClipRRect(defaultRadius),
                              Positioned(
                                top: 110 * 3 / 4 + 4,
                                left: 110 * 3 / 4 + 4,
                                child: GestureDetector(
                                  onTap: () {
                                    hideKeyboard(context);
                                    vetServiceController.showBottomSheet(context);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(3),
                                    decoration: boxDecorationDefault(shape: BoxShape.circle, color: Colors.white),
                                    child: Container(
                                      padding: const EdgeInsets.all(5),
                                      decoration: boxDecorationDefault(shape: BoxShape.circle, color: primaryColor),
                                      child: const Icon(Icons.edit, size: 16, color: Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ).paddingBottom(16),
                        )
                      : Column(
                          children: [
                            AppPrimaryWidget(
                              width: Get.width,
                              constraints: const BoxConstraints(minHeight: 80),
                              border: Border.all(color: primaryColor),
                              borderRadius: defaultRadius,
                              onTap: () {
                                hideKeyboard(context);
                                vetServiceController.showBottomSheet(context);
                              },
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.add_circle_outline_rounded, color: primaryColor, size: 24),
                                  8.height,
                                  Text(
                                    'Choose Image', //TODO: string
                                    style: boldTextStyle(color: primaryColor, size: 14),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                            16.height,
                            //TODO: string
                            Text('Note: You can upload image with \'jpg\', \'png\', \'jpeg\' extensions & you can select only one image', style: secondaryTextStyle(size: 10)),
                          ],
                        ),
                ),
                16.height,
                AppTextField(
                  title: locale.value.serviceName,
                  textStyle: primaryTextStyle(size: 12),
                  controller: vetServiceController.serviceCont,
                  focus: vetServiceController.serviceNameFocus,
                  nextFocus: vetServiceController.serviceDurationFocus,
                  textFieldType: TextFieldType.NAME,
                  decoration: inputDecoration(
                    context,
                    hintText: loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary)
                        ? "${locale.value.eG}  ${locale.value.pet} ${locale.value.nutrition} ${locale.value.consultation}"
                        : loginUserData.value.userRole.contains(EmployeeKeyConst.grooming)
                            ? "${locale.value.eG}  ${locale.value.flea} ${locale.value.and} ${locale.value.tick} ${locale.value.bath}"
                            : loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary)
                                ? "${locale.value.eG}  ${locale.value.leashTraining}"
                                : "${locale.value.eG}  ${locale.value.serviceName}",
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                ).visible(loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary) || loginUserData.value.userRole.contains(EmployeeKeyConst.grooming) || loginUserData.value.userRole.contains(EmployeeKeyConst.training)),
                16.height,
                Obx(
                  () => AppTextField(
                    title: locale.value.category,
                    textStyle: primaryTextStyle(size: 12),
                    controller: vetServiceController.vetCont,
                    textFieldType: TextFieldType.NAME,
                    readOnly: true,
                    onTap: () async {
                      serviceCommonBottomSheet(context,
                          child: Obx(
                            () => BottomSelectionSheet(
                              title: locale.value.chooseCategory,
                              hintText: locale.value.searchForCategory,
                              controller: vetServiceController.searchCont,
                              hasError: vetServiceController.hasErrorFetchingVet.value,
                              onChanged: vetServiceController.onCategorySearchChange,
                              isEmpty: vetServiceController.isShowFullList ? vetServiceController.categoryList.isEmpty : vetServiceController.categoryFilterList.isEmpty,
                              errorText: vetServiceController.errorMessageVet.value,
                              isLoading: vetServiceController.isLoading,
                              noDataTitle: locale.value.categoryListIsEmpty,
                              noDataSubTitle: locale.value.thereAreNoCategory,
                              onRetry: () {
                                vetServiceController.getCategory();
                              },
                              listWidget: Obx(
                                () => veterinaryTypeListWid(
                                  vetServiceController.isShowFullList ? vetServiceController.categoryList : vetServiceController.categoryFilterList,
                                ).expand(),
                              ),
                            ),
                          ));
                    },
                    decoration: inputDecoration(context,
                        hintText: loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary)
                            ? "${locale.value.eG}  ${locale.value.videoConsultancy}"
                            : loginUserData.value.userRole.contains(EmployeeKeyConst.grooming)
                                ? "${locale.value.eG}  ${locale.value.bathingAndShampooing}"
                                : "${locale.value.eG} ${locale.value.categoryType}",
                        fillColor: context.cardColor,
                        filled: true,
                        prefixIconConstraints: BoxConstraints.loose(const Size.square(60)),
                        prefixIcon: vetServiceController.selectedVeterinaryType.value.categoryImage.isEmpty && vetServiceController.selectedVeterinaryType.value.id.isNegative
                            ? null
                            : CachedImageWidget(
                                url: vetServiceController.selectedVeterinaryType.value.categoryImage,
                                height: 35,
                                width: 35,
                                firstName: vetServiceController.selectedVeterinaryType.value.name,
                                fit: BoxFit.cover,
                                circle: true,
                                usePlaceholderIfUrlEmpty: true,
                              ).paddingOnly(left: 12, top: 8, bottom: 8, right: 12),
                        suffixIcon: vetServiceController.selectedVeterinaryType.value.categoryImage.isNotEmpty && vetServiceController.selectedVeterinaryType.value.id.isNegative
                            ? Icon(Icons.keyboard_arrow_down_rounded, size: 24, color: darkGray.withOpacity(0.5))
                            : Icon(Icons.keyboard_arrow_down_rounded, size: 24, color: darkGray.withOpacity(0.5))),
                  ),
                ).visible(loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary) || loginUserData.value.userRole.contains(EmployeeKeyConst.grooming)),
                16.height,
                AppTextField(
                  title: "${locale.value.serviceDuration} ${(locale.value.mins)}",
                  textStyle: primaryTextStyle(size: 12),
                  controller: vetServiceController.durationCont,
                  focus: vetServiceController.serviceDurationFocus,
                  nextFocus: vetServiceController.defaultPriceFocus,
                  textFieldType: TextFieldType.NUMBER,
                  decoration: inputDecoration(
                    context,
                    hintText: "${locale.value.eG} 30 ${locale.value.min}",
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                ).visible(loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary) || loginUserData.value.userRole.contains(EmployeeKeyConst.grooming)),
                16.height,
                AppTextField(
                  title: locale.value.defaultPrice,
                  textStyle: primaryTextStyle(size: 12),
                  controller: vetServiceController.priceCont,
                  textFieldType: TextFieldType.NUMBER,
                  focus: vetServiceController.defaultPriceFocus,
                  nextFocus: vetServiceController.descriptionFocus,
                  decoration: inputDecoration(
                    context,
                    hintText: "${locale.value.eG} \$90.00",
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                ).visible(loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary) || loginUserData.value.userRole.contains(EmployeeKeyConst.grooming)),
                16.height,
                AppTextField(
                  title: locale.value.description,
                  textStyle: primaryTextStyle(size: 12),
                  controller: vetServiceController.descriptionCont,
                  focus: vetServiceController.descriptionFocus,
                  minLines: 3,
                  nextFocus: vetServiceController.descriptionFocus,
                  textFieldType: TextFieldType.MULTILINE,
                  enableChatGPT: ENABLE_CHATGPT,
                  promptFieldInputDecorationChatGPT: inputDecoration(context, hintText: 'Write Here', fillColor: context.scaffoldBackgroundColor, filled: true), //TODO: string
                  testWithoutKeyChatGPT: TEST_WITHOUT_KEY_CHATGPT,
                  loaderWidgetForChatGPT: const ChatGPTLoadingWidget(),
                  decoration: inputDecoration(
                    context,
                    hintText: loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary)
                        ? "${locale.value.eG}  ${locale.value.healthyDogFeedingGuide}"
                        : loginUserData.value.userRole.contains(EmployeeKeyConst.grooming)
                            ? "${locale.value.eG}  ${locale.value.targetedTreatmentToEliminate} & ${locale.value.ticks}"
                            : loginUserData.value.userRole.contains(EmployeeKeyConst.training)
                                ? "${locale.value.eG}  ${locale.value.teachingPetsToWalk}"
                                : "${locale.value.eG}  ${locale.value.description}",
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                ).visible(loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary) || loginUserData.value.userRole.contains(EmployeeKeyConst.grooming) || loginUserData.value.userRole.contains(EmployeeKeyConst.training)),
                16.height,
                AppButton(
                  width: Get.width,
                  color: primaryColor,
                  onTap: () {
                    if (!vetServiceController.isLoading.value) {
                      if (vetServiceController.imageFile.value.path.isNotEmpty || vetServiceController.serviceImage.isNotEmpty) {
                        if (formKey.currentState!.validate()) {
                          formKey.currentState!.save();

                          /// Add Or Edit Service Api Call
                          if (loginUserData.value.userRole.contains(EmployeeKeyConst.veterinary) || loginUserData.value.userRole.contains(EmployeeKeyConst.grooming)) {
                            vetServiceController.addServices();
                          } else if (loginUserData.value.userRole.contains(EmployeeKeyConst.training)) {
                            vetServiceController.addServicesTraining();
                          }
                        }
                      } else {
                        toast('Please select a Service Image'); //TODO: string
                        /// Open Gallery
                        hideKeyboard(context);
                        vetServiceController.showBottomSheet(context);
                      }
                    }
                  },
                  //TODO: string
                  child: Text(vetServiceController.isEdit.value ? 'Save' : locale.value.save, style: primaryTextStyle(color: white)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget veterinaryTypeListWid(List<ShopCategoryModel> list) {
    return ListView.separated(
      itemCount: list.length,
      shrinkWrap: true,
      itemBuilder: (context, index) {
        return SettingItemWidget(
          title: list[index].name,
          titleTextStyle: primaryTextStyle(size: 14),
          leading: CachedImageWidget(url: list[index].categoryImage, height: 35, fit: BoxFit.cover, width: 35, circle: true),
          onTap: () {
            vetServiceController.selectedVeterinaryType(list[index]);
            vetServiceController.vetCont.text = list[index].name;
            Get.back();
          },
        );
      },
      separatorBuilder: (context, index) => commonDivider.paddingSymmetric(vertical: 6),
    );
  }
}
