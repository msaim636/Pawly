import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../utils/app_common.dart';
import '../../utils/constants.dart';
import '../../utils/local_storage.dart';
import '../../utils/one_signal_utils.dart';
import '../auth/services/auth_services.dart';
import 'model/dashboard_res_model.dart';
import 'services/home_service_api.dart';

class HomeController extends GetxController with GetSingleTickerProviderStateMixin {
  RxBool isLoading = false.obs;
  RxBool isRefresh = false.obs;
  Rx<Future<DashboardRes>> getDashboardDetailFuture = Future(() => DashboardRes(data: DashboardData())).obs;
  Rx<DashboardData> dashboardData = DashboardData().obs;

  @override
  void onReady() {
    init();
    super.onReady();
  }

  void init() {
    try {
      final dashboardResFromLocal = getValueFromLocal(APICacheConst.DASHBOARD_RESPONSE);
      getAppConfigurations();
      if (dashboardResFromLocal != null) {
        handleDashboardRes(DashboardRes.fromJson(dashboardResFromLocal));
      }
    } catch (e) {
      log('handleDashboardRes from cache E: $e');
    }
    getDashboardDetail();
  }

  ///Get ChooseService List
  getDashboardDetail({bool isFromSwipeRefresh = false}) async {
    if (!isFromSwipeRefresh) {
      isLoading(true);
      getAppConfigurations();
    }
    await getDashboardDetailFuture(HomeServiceApi.getDashboard()).then((value) {
      handleDashboardRes(value);
      try {
        setValueToLocal(APICacheConst.DASHBOARD_RESPONSE, value.toJson());
      } catch (e) {
        log('store DASHBOARD_RESPONSE E: $e');
      }
    }).whenComplete(() => isLoading(false));
  }

  void handleDashboardRes(DashboardRes value) {
    dashboardData(value.data);
    isRefresh(true);
    isRefresh(false);
  }

  getAppConfigurations() {
    AuthService.getAppConfigurations().then((value) {
      appCurrency(value.currency);
      appConfigs(value);
      if (getValueFromLocal(SharedPreferenceConst.IS_LOGGED_IN) == true && appConfigs.value.isUserPushNotification.getBoolInt() && appConfigs.value.onesignalEmployeeApp.employeeOnesignalAppId.isNotEmpty) {
        initOneSignal();
      }
      setValueToLocal(APICacheConst.APP_CONFIGURATION_RESPONSE, value.toJson());
    }).onError((error, stackTrace) {
      toast(error.toString());
    });
  }
}
