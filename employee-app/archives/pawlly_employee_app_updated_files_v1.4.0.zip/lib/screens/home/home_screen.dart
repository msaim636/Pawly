// ignore_for_file: invalid_use_of_protected_member

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly_employee/components/app_scaffold.dart';

import '../../components/employee_total_widget.dart';
import '../../components/loader_widget.dart';
import '../../generated/assets.dart';
import '../../main.dart';
import '../../utils/app_common.dart';
import '../../utils/common_base.dart';
import '../../utils/empty_error_state_widget.dart';
import '../../utils/view_all_label_component.dart';
import '../auth/other/notification_screen.dart';
import '../auth/review/employee_review_components.dart';
import '../booking_module/booking_list/bookings_card.dart';
import 'dashboard_controller.dart';
import 'home_controller.dart';
import 'model/dashboard_res_model.dart';

class HomeScreen extends StatelessWidget {
  final HomeController homeScreenController = Get.put(HomeController());

  HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      hideAppBar: true,
      hasLeadingWidget: false,
      isLoading: homeScreenController.isLoading,
      body: RefreshIndicator(
        onRefresh: () async {
          return await homeScreenController.getDashboardDetail(isFromSwipeRefresh: true);
        },
        child: Obx(
          () => SnapHelperWidget(
            future: homeScreenController.getDashboardDetailFuture.value,
            initialData: DashboardRes(data: homeScreenController.dashboardData.value),
            errorBuilder: (error) {
              return NoDataWidget(
                title: error,
                retryText: locale.value.reload,
                imageWidget: const ErrorStateWidget(),
                onRetry: () {
                  homeScreenController.init();
                },
              ).paddingSymmetric(horizontal: 16);
            },
            loadingWidget: homeScreenController.isLoading.value ? const Offstage() : const LoaderWidget(),
            onSuccess: (dashboardData) {
              return SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 16),
                physics: const AlwaysScrollableScrollPhysics(),
                scrollDirection: Axis.vertical,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    40.height,
                    Row(
                      children: [
                        Obx(
                          () => Text(
                            '${locale.value.hello}, ${loginUserData.value.userName.isNotEmpty ? loginUserData.value.userName : locale.value.guest} 👋',
                            style: primaryTextStyle(size: 20),
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () {
                            Get.to(() => NotificationScreen());
                          },
                          behavior: HitTestBehavior.translucent,
                          child: Image.asset(Assets.iconsIcNotification, width: 26, height: 26),
                        ),
                      ],
                    ).paddingSymmetric(horizontal: 16),
                    16.height,
                    Obx(
                      () => Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          16.height,
                          Row(
                            children: [
                              EmployeeTotalWidget(
                                title: 'Total Booking', //TODO: string
                                total: homeScreenController.dashboardData.value.totalBooking.toString(),
                                icon: Assets.iconsIcTotalBooking,
                              ).onTap(
                                () {
                                  //
                                },
                                highlightColor: Colors.transparent,
                                splashColor: Colors.transparent,
                              ).expand(),
                              16.width,
                              EmployeeTotalWidget(
                                title: 'Employee Earning', //TODO: string
                                total: homeScreenController.dashboardData.value.employeeEarning.toString(),
                                icon: Assets.iconsIcPercentLine,
                                isPrice: true,
                              ).onTap(
                                () {
                                  //
                                },
                                highlightColor: Colors.transparent,
                                splashColor: Colors.transparent,
                              ).expand(),
                            ],
                          ).paddingSymmetric(horizontal: 16),
                          16.height,
                          ViewAllLabel(
                            label: locale.value.bookings,
                            onTap: () {
                              bottomNavigateByIndex(1);
                            },
                          ).paddingSymmetric(horizontal: 16),
                          Obx(
                            () => homeScreenController.isLoading.value
                                ? Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("${locale.value.loading}.... ", style: secondaryTextStyle(size: 14, fontFamily: fontFamilyFontBold)).paddingSymmetric(vertical: Get.height * 0.12),
                                    ],
                                  )
                                : Column(
                                    children: [
                                      AnimatedListView(
                                        shrinkWrap: true,
                                        listAnimationType: ListAnimationType.None,
                                        itemCount: homeScreenController.dashboardData.value.upcommingBooking.take(3).length,
                                        physics: const NeverScrollableScrollPhysics(),
                                        emptyWidget: NoDataWidget(
                                          title: 'No Upcoming bookings yet', //TODO: String
                                        ).paddingSymmetric(horizontal: 16),
                                        padding: const EdgeInsets.symmetric(horizontal: 16),
                                        itemBuilder: (context, index) {
                                          return BookingsCard(booking: homeScreenController.dashboardData.value.upcommingBooking[index], isFromBookings: true);
                                        },
                                      ),
                                    ],
                                  ).paddingBottom(12),
                          ),
                          Obx(
                            () => ViewAllLabel(
                              label: locale.value.myReviews,
                              onTap: () {
                                bottomNavigateByIndex(2);
                              },
                              list: homeScreenController.dashboardData.value.review,
                            ).paddingSymmetric(horizontal: 16),
                          ),
                          Obx(
                            () => homeScreenController.isLoading.value
                                ? Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("${locale.value.loading}.... ", style: secondaryTextStyle(size: 14, fontFamily: fontFamilyFontBold)).paddingSymmetric(vertical: Get.height * 0.12),
                                    ],
                                  )
                                : Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(
                                        () => AnimatedListView(
                                          shrinkWrap: true,
                                          listAnimationType: ListAnimationType.None,
                                          itemCount: homeScreenController.dashboardData.value.review.length,
                                          physics: const NeverScrollableScrollPhysics(),
                                          padding: const EdgeInsets.symmetric(horizontal: 16),
                                          emptyWidget: NoDataWidget(
                                            title: 'No Ratings yet', //TODO: String
                                          ).paddingSymmetric(horizontal: 32),
                                          itemBuilder: (context, index) {
                                            return EmployeeReviewComponents(employeeReview: homeScreenController.dashboardData.value.review[index]);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
