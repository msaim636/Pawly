import '../../../models/review_data.dart';
import '../../booking_module/model/bookings_model.dart';

class DashboardRes {
  bool status;
  DashboardData data;
  String message;

  DashboardRes({
    this.status = false,
    required this.data,
    this.message = "",
  });

  factory DashboardRes.fromJson(Map<String, dynamic> json) {
    return DashboardRes(
      status: json['status'] is bool ? json['status'] : false,
      data: json['data'] is Map ? DashboardData.fromJson(json['data']) : DashboardData(),
      message: json['message'] is String ? json['message'] : "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'status': status,
      'data': data.toJson(),
      'message': message,
    };
  }
}

class DashboardData {
  num totalBooking;
  num employeeEarning;
  List<BookingDataModel> upcommingBooking;
  List<ReviewData> review;

  DashboardData({
    this.totalBooking = 0,
    this.employeeEarning = 0,
    this.upcommingBooking = const <BookingDataModel>[],
    this.review = const <ReviewData>[],
  });

  factory DashboardData.fromJson(Map<String, dynamic> json) {
    return DashboardData(
      totalBooking: json['total_booking'] is num ? json['total_booking'] : 0.0,
      employeeEarning: json['employee_earning'] is num ? json['employee_earning'] : 0.0,
      upcommingBooking: json['upcomming_booking'] is List ? List<BookingDataModel>.from(json['upcomming_booking'].map((x) => BookingDataModel.fromJson(x))) : [],
      review: json['review'] is List ? List<ReviewData>.from(json['review'].map((x) => ReviewData.fromJson(x))) : [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'total_booking': totalBooking,
      'employee_earning': employeeEarning,
      'upcomming_booking': review.map((e) => e.toJson()).toList(),
      'review': review.map((e) => e.toJson()).toList(),
    };
  }
}
