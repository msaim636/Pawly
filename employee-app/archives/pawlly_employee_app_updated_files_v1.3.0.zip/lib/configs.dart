// ignore_for_file: constant_identifier_names

const APP_NAME = 'Pawlly Employee';
const DEFAULT_LANGUAGE = 'en';

///Live Url
const DOMAIN_URL = "";

const BASE_URL = '$DOMAIN_URL/api/';


//endregion

const APP_PLAY_STORE_URL = '';
const APP_APPSTORE_URL = '';

const TERMS_CONDITION_URL = '$BASE_URL/page/term-condition';
const PRIVACY_POLICY_URL = '$BASE_URL/page/privacy-policy';
const INQUIRY_SUPPORT_EMAIL = 'demo@gmail.com';
const DASHBOARD_AUTO_SLIDER_SECOND = 5;

/// You can add help line number here for contact. It's demo number
const HELP_LINE_NUMBER = '+15265897485';
