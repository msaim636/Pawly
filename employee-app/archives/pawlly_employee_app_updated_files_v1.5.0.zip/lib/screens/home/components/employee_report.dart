import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly_employee/screens/home/home_controller.dart';
import '../../../components/employee_total_widget.dart';
import '../../../generated/assets.dart';

class EmpoyeeReports extends StatelessWidget {
  EmpoyeeReports({super.key});
  final HomeController homeController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          16.height,
          Row(
            children: [
              EmployeeTotalWidget(
                title: 'Total Booking', //TODO: string
                total: homeController.dashboardData.value.totalBooking.toString(),
                icon: Assets.iconsIcTotalBooking,
              ).expand(),
              16.width,
              EmployeeTotalWidget(
                title: 'Employee Earning', //TODO: string
                total: homeController.dashboardData.value.employeeEarning.toString(),
                icon: Assets.iconsIcPercentLine,
                isPrice: true,
              ).expand(),
            ],
          ),
        ],
      ).paddingSymmetric(horizontal: 16),
    );
  }
}
