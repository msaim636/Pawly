import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import '../../../generated/assets.dart';
import '../../../main.dart';
import '../../../utils/app_common.dart';
import '../../auth/other/notification_screen.dart';

class GreetingsComponent extends StatelessWidget {
  const GreetingsComponent({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Obx(
          () => Text(
            '${locale.value.hello}, ${loginUserData.value.userName.isNotEmpty ? loginUserData.value.userName : locale.value.guest} 👋',
            style: primaryTextStyle(size: 20),
          ),
        ),
        const Spacer(),
        GestureDetector(
          onTap: () {
            Get.to(() => NotificationScreen());
          },
          behavior: HitTestBehavior.translucent,
          child: Image.asset(Assets.iconsIcNotification, width: 26, height: 26),
        ),
      ],
    ).paddingSymmetric(horizontal: 16);
  }
}
