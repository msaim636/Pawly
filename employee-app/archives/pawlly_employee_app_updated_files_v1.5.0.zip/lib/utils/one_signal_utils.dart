import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:pawlly_employee/utils/constants.dart';

import '../screens/auth/services/auth_services.dart';
import '../screens/booking_module/booking_detail/booking_detail_screen.dart';
import '../screens/booking_module/model/bookings_model.dart';
import 'app_common.dart';

bool isOneSignalInitialized = false;

Future<void> initOneSignal() async {
  if (!isOneSignalInitialized && appConfigs.value.onesignalEmployeeApp.employeeOnesignalAppId.isNotEmpty) {
    OneSignal.initialize(appConfigs.value.onesignalEmployeeApp.employeeOnesignalAppId);
    log('OneSignal Initialized');

    // await Future.delayed(const Duration(seconds: 2));
    // OneSignal.Notifications.requestPermission(true);
    OneSignal.User.pushSubscription.optIn();

    ///Handle Navigation
    OneSignal.Notifications.addClickListener((event) {
      try {
        log("notification data===> ${event.jsonRepresentation()}");
        if (event.notification.additionalData != null) {
          final additionalData = event.notification.additionalData!['additional_data'];
          if (event.notification.additionalData!['additional_data'].containsKey('id')) {
            int? notId = event.notification.additionalData!['additional_data']["id"];
            if (notId != null) {
              Get.to(() => BookingDetailScreen(), arguments: BookingDataModel(id: notId, service: SystemService(name: additionalData['booking_services_names']), payment: PaymentDetails(), training: Training()));
            }
          }
        }
      } catch (e) {
        log('OneSignal addClickListener E: $e');
      }
    });

    isOneSignalInitialized = true;

    ///Save Player Id to Backend
    saveOneSignalPlayerId();
  }
}

Future<void> saveOneSignalPlayerId() async {
  if (isLoggedIn.value) {
    OneSignal.User.addTagWithKey(UserKeys.email, loginUserData.value.email);

    OneSignal.login(loginUserData.value.id.toString()).then((value) async {
      if (OneSignal.User.pushSubscription.id.validate().isNotEmpty) {
        playerId(OneSignal.User.pushSubscription.id);
        AuthServiceApis.updateProfile(playerId: playerId.value).catchError((e) {
          log('saveOneSignalPlayerId updateProfile E: $e');
        });
        log('+++++PLAYERID: ${playerId.value}');
      }
    }).catchError((e) {
      log('Error saving subscription id - $e');
    });
  }
}
