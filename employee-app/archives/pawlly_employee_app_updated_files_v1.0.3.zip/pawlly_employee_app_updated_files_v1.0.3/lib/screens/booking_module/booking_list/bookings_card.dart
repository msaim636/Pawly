import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly_employee/utils/constants.dart';

import '../../../components/cached_image_widget.dart';
import '../../../components/price_widget.dart';
import '../../../generated/assets.dart';
import '../../../main.dart';
import '../../../utils/app_common.dart';
import '../../../utils/colors.dart';
import '../../../utils/common_base.dart';
import '../booking_detail/booking_detail_screen.dart';
import '../model/bookings_model.dart';
import 'bookings_controller.dart';

class BookingsCard extends StatelessWidget {
  final BookingDataModel appointment;
  final bool isfromBookings;
  final VoidCallback? onUpdateBooking;
  BookingsCard({super.key, this.isfromBookings = false, this.onUpdateBooking, required this.appointment});

  final BookingsController appointmentsController = Get.find();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        hideKeyboard(context);
        Get.to(() => BookingDetailScreen(), arguments: appointment, duration: const Duration(milliseconds: 200));
      },
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 8, bottom: 8),
            decoration: boxDecorationDefault(color: context.cardColor, shape: BoxShape.rectangle),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              16.height,
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Hero(tag: '#${appointment.id}', child: Text('#${appointment.id} - ${appointment.service.name}', style: primaryTextStyle(decoration: TextDecoration.none))),
                ],
              ).paddingSymmetric(horizontal: 16),
              8.height,
              Row(
                children: [
                  Text(locale.value.bookingStatus, style: secondaryTextStyle()),
                  const Spacer(),
                  Text(
                    getBookingStatusEmployee(status: appointment.status.capitalizeFirstLetter()),
                    style: primaryTextStyle(size: 12, color: getBookingStatusColor(status: appointment.status)),
                  ),
                  // Text(appointment.status.capitalizeFirstLetter(), style: primaryTextStyle(size: 12, color: appointment.status.toLowerCase().contains(StatusConst.pending) ? pendingStatusColor : defaultStatusColor)),
                ],
              ).paddingSymmetric(horizontal: 16),
              16.height,
              commonDivider,
              16.height,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(appointment.customerName, style: primaryTextStyle()).expand(),
                  CachedImageWidget(
                    url: appointment.customerImage,
                    height: 38,
                    width: 38,
                    fit: BoxFit.cover,
                    circle: true,
                  ),
                ],
              ).paddingSymmetric(horizontal: 16),
              8.height,
              Column(
                children: [
                  detailWidget(image: Assets.navigationIcCalendarOutlined, title: locale.value.dateAndTime, value: scheduleDate).visible(appointment.startDateTime.isNotEmpty),
                  detailWidget(image: Assets.iconsIcDuration, title: locale.value.duration, value: appointment.duration.toFormattedDuration(showFullTitleHoursMinutes: true)),
                  Row(
                    children: [
                      4.width,
                      Image.asset(
                        Assets.profileIconsIcMyPets,
                        width: 15,
                        height: 15,
                        color: switchColor,
                      ),
                      4.width,
                      Marquee(child: Text(locale.value.pet, style: secondaryTextStyle(), textAlign: TextAlign.left)).expand(flex: 3),
                      12.width,
                      Text(":", style: secondaryTextStyle()),
                      10.width,
                      CachedImageWidget(
                        url: appointment.petImage,
                        height: 20,
                        width: 20,
                        circle: true,
                        radius: 20,
                        fit: BoxFit.cover,
                      ),
                      4.width,
                      Marquee(child: Text('${appointment.petName} (${appointment.breed})', style: primaryTextStyle(size: 12), textAlign: TextAlign.right)).expand(flex: 6),
                    ],
                  ),
                  8.height,
                  detailWidgetPrice(title: locale.value.totalAmount, value: appointment.payment.totalAmount, textColor: getPriceStatusColor(appointment: appointment), isBoldText: true, image: Assets.iconsIcPrice),
                  detailWidget(image: Assets.iconsIcAddress, title: locale.value.location, value: getAddressByServiceElement(appointment: appointment)),
                  detailWidget(image: Assets.iconsIcReason, title: locale.value.reason, value: appointment.veterinaryReason).visible(appointment.veterinaryReason.isNotEmpty),
                ],
              ).paddingSymmetric(horizontal: 8),
              if (appointment.status.contains(BookingStatusConst.PENDING) || appointment.status.contains(BookingStatusConst.CONFIRMED) || appointment.status.contains(BookingStatusConst.INPROGRESS)) ...[
                8.height,
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (appointment.status.contains(BookingStatusConst.PENDING))
                      AppButton(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          margin: const EdgeInsets.only(right: 8, left: 8),
                          color: primaryColor,
                          textStyle: appButtonTextStyleWhite,
                          text: locale.value.confirm,
                          onTap: () {
                            showConfirmDialogCustom(
                              getContext,
                              primaryColor: primaryColor,
                              negativeText: locale.value.cancel,
                              positiveText: locale.value.yes,
                              onAccept: (_) {
                                appointmentsController.updateBooking(
                                  bookingId: appointment.id,
                                  status: BookingStatusConst.CONFIRMED,
                                  onUpdateBooking: onUpdateBooking,
                                );
                              },
                              dialogType: DialogType.DELETE,
                              title: locale.value.areYouSureWantToConfirm,
                            );
                          }).expand(),
                    if (appointment.status.contains(BookingStatusConst.PENDING) && !appointment.payment.paymentStatus.toLowerCase().contains(PaymentStatus.PAID))
                      AppButton(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          margin: const EdgeInsets.only(right: 8, left: 8),
                          textStyle: appButtonTextStyleGray,
                          color: isDarkMode.value ? lightPrimaryColor2 : buttonLightColor,
                          text: locale.value.reject,
                          onTap: () {
                            showConfirmDialogCustom(
                              getContext,
                              primaryColor: primaryColor,
                              negativeText: locale.value.cancel,
                              positiveText: locale.value.yes,
                              onAccept: (_) {
                                appointmentsController.updateBooking(
                                  bookingId: appointment.id,
                                  status: BookingStatusConst.REJECTED,
                                  onUpdateBooking: onUpdateBooking,
                                );
                              },
                              dialogType: DialogType.DELETE,
                              title: locale.value.areYouSureWantToRejectBooking,
                            );
                          }).expand(),
                    AppButton(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        margin: const EdgeInsets.only(right: 8, left: 8),
                        text: locale.value.start,
                        width: Get.width,
                        color: primaryColor,
                        textStyle: appButtonTextStyleWhite,
                        onTap: () {
                          appointmentsController.updateBooking(
                            bookingId: appointment.id,
                            status: BookingStatusConst.INPROGRESS,
                            onUpdateBooking: onUpdateBooking,
                          );
                        }).expand().visible(appointment.status.contains(BookingStatusConst.CONFIRMED)),
                    AppButton(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        margin: const EdgeInsets.only(right: 8, left: 8),
                        text: locale.value.complete,
                        width: Get.width,
                        color: primaryColor,
                        textStyle: appButtonTextStyleWhite,
                        onTap: () {
                          appointmentsController.updateBooking(
                            bookingId: appointment.id,
                            status: BookingStatusConst.COMPLETED,
                            onUpdateBooking: onUpdateBooking,
                          );
                        }).expand().visible(appointment.status.contains(BookingStatusConst.INPROGRESS)),
                    AppButton(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        margin: const EdgeInsets.only(right: 8, left: 8),
                        text: locale.value.call,
                        width: Get.width,
                        color: lightPrimaryColor,
                        textStyle: appButtonPrimaryColorText,
                        onTap: () {
                          launchCall((appointment.customerContact));
                        }).expand(),
                  ],
                ),
              ],
              16.height,
            ]),
          ),
        ],
      ),
    );
  }

  String get scheduleDate {
    try {
      return appointment.startDateTime.isValidDateTime ? appointment.startDateTime.dateInddMMMyyyyHHmmAmPmFormat : " - ";
    } catch (e) {
      debugPrint('get scheduleDate E: $e');
      return " - ";
    }
  }

  Widget detailWidget({required String image, required String title, required String value, Color? textColor}) {
    return Row(
      children: [
        4.width,
        Image.asset(
          image,
          width: 15,
          height: 15,
          color: switchColor,
        ),
        4.width,
        Marquee(child: Text(title, style: secondaryTextStyle(), textAlign: TextAlign.left)).expand(flex: 3),
        Text(":", style: secondaryTextStyle()),
        10.width,
        Marquee(child: Text(value, style: primaryTextStyle(size: 12, color: textColor), textAlign: TextAlign.right)).expand(flex: 6),
      ],
    ).paddingBottom(8).visible(value.isNotEmpty);
  }

  Widget detailWidgetPrice({required String image, required String title, required num value, Color? textColor, bool isBoldText = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        4.width,
        Image.asset(
          image,
          width: 15,
          height: 15,
          color: switchColor,
        ),
        4.width,
        Marquee(child: Text(title, style: secondaryTextStyle(), textAlign: TextAlign.left)).expand(flex: 3),
        Text(":", style: secondaryTextStyle()),
        10.width,
        PriceWidget(
          price: value,
          color: textColor ?? black,
          size: 12,
          isBoldText: isBoldText,
        ).expand(flex: 6)
      ],
    ).paddingBottom(10);
  }
}
