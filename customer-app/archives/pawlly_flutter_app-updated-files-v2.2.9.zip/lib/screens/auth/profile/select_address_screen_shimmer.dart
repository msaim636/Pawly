import 'package:get/get.dart';
import 'package:pawlly/utils/library.dart';

class SelectAddressScreenShimmer extends StatelessWidget {
  const SelectAddressScreenShimmer({super.key});

  Widget addressItemComponentShimmer(BuildContext ctx) {
    return Container(
      width: Get.width - 32,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: boxDecorationDefault(color: ctx.cardColor),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            children: [
              ShimmerWidget(
                baseColor: isDarkMode.value
                    ? shimmerDarkBaseColor
                    : shimmerLightBaseColor,
                child: const CircleWidget(
                  padding: EdgeInsets.all(12),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  3,
                  (index) => ShimmerWidget(
                    backgroundColor: isDarkMode.value
                        ? shimmerDarkBaseColor
                        : shimmerLightBaseColor,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  ).paddingSymmetric(horizontal: 16, vertical: 4),
                ),
              ).expand(),
              ShimmerWidget(
                  backgroundColor: isDarkMode.value
                      ? shimmerDarkBaseColor
                      : shimmerLightBaseColor,
                  padding: const EdgeInsets.all(16)),
              16.width,
              ShimmerWidget(
                  backgroundColor: isDarkMode.value
                      ? shimmerDarkBaseColor
                      : shimmerLightBaseColor,
                  padding: const EdgeInsets.all(16))
            ],
          ).paddingSymmetric(horizontal: 16),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ScreenShimmer(
        shimmerComponent: addressItemComponentShimmer(context).paddingLeft(16));
  }
}