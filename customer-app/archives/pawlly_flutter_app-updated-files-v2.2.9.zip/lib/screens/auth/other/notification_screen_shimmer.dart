import 'package:get/get.dart';
import 'package:pawlly/utils/library.dart';

class NotificationScreenShimmer extends StatelessWidget {
  const NotificationScreenShimmer({super.key});

  Widget notificationComponentShimmer() {
    return SizedBox(
      width: Get.width - 32,
      child: Column(
        children: [
          Row(
            children: [
              ShimmerWidget(
                baseColor: shimmerLightBaseColor,
                child: const CircleWidget(
                  padding: EdgeInsets.all(18),
                ),
              ),
              Column(
                children: List.generate(
                  3,
                  (index) => const ShimmerWidget(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  ).paddingRight(70).paddingSymmetric(vertical: 4),
                ),
              ).paddingSymmetric(horizontal: 16).expand(),
              CircleWidget(
                circleColor: shimmerLightBaseColor,
                padding: const EdgeInsets.all(4),
                child: ShimmerWidget(
                  child: Icon(
                    Icons.close_rounded,
                    size: 18,
                    color: shimmerPrimaryBaseColor.withValues(alpha: 0.4),
                  ),
                ),
              ),
            ],
          ),
          ShimmerWidget(
            child: Divider(
              color: shimmerPrimaryBaseColor.withValues(alpha: 0.4),
              height: 16,
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ScreenShimmer(
      shimmerComponent: notificationComponentShimmer(),
      itemCount: 15,
    );
  }
}