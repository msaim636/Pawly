import 'package:get/get.dart';
import '../../dashboard/dashboard_res_model.dart';
import 'package:pawlly/utils/library.dart';

class BookingDetailsController extends GetxController {
  RxBool isLoading = false.obs;
  RxBool hasReview = false.obs;
  RxBool showWriteReview = false.obs;
  Rx<Future<BookingDetailRes>> getBookingDetails = Future(() => BookingDetailRes(data: BookingDataModel(service: SystemService(), payment: PaymentDetails(), training: Training()))).obs;
  Rx<EmployeeReviewData> yourReview = EmployeeReviewData().obs;

  TextEditingController paymentMethod = TextEditingController();
  RxDouble selectedRating = (0.0).obs;
  TextEditingController reviewCont = TextEditingController();
  Rx<BookingDataModel> bookingDetail = BookingDataModel(service: SystemService(), payment: PaymentDetails(), training: Training()).obs;

  //Get Facility List
  RxList<FacilityModel> facilities = RxList();

  int rating = 0;

  @override
  void onInit() {
    if (Get.arguments is BookingDataModel) {
      bookingDetail(Get.arguments);
    }
    init(showLoader: false);
    super.onInit();
  }

  ///Get Booking Detail
  Future<void> init({bool showLoader = true}) async {
    if (showLoader) {
      isLoading(true);
    }
    await getBookingDetails(
      BookingServiceApis.getBookingDetail(
        bookingId: bookingDetail.value.id,
        noteId: bookingDetail.value.notificationId,
      ),
    ).then((value) {
      bookingDetail(value.data);
      facilities(bookingDetail.value.additionalFacility);
      hasReview(value.customerReview != null);
      if (value.customerReview != null) {
        yourReview(value.customerReview);
      }
      isLoading(false);
    }).whenComplete(() => isLoading(false));
  }

  void deleteReviewHandleClick() {
    showConfirmDialogCustom(
      getContext,
      primaryColor: primaryColor,
      negativeText: locale.value.cancel,
      positiveText: locale.value.yes,
      onAccept: (_) {
        deleteReview();
      },
      dialogType: DialogType.DELETE,
      title: locale.value.doYouWantToRemoveThisReview,
    );
  }

  Future<void> saveReview() async {
    isLoading(true);
    hideKeyBoardWithoutContext();

    Map<String, dynamic> req = {
      "id": yourReview.value.id.isNegative ? "" : yourReview.value.id,
      "employee_id": bookingDetail.value.employeeId,
      "rating": selectedRating.value,
      "review_msg": reviewCont.text.trim(),
    };

    await BookingServiceApis.updateReview(request: req).then((value) async {
      log('updateReview: ${value.toJson()}');
      toast(value.message);
      showWriteReview(false);
      hasReview(true);
      yourReview(EmployeeReviewData(
        rating: selectedRating.value,
        userId: loginUserData.value.id,
        reviewMsg: reviewCont.text.trim(),
        username: loginUserData.value.userName,
        employeeId: bookingDetail.value.employeeId,
      ));
      init(showLoader: true);
      isLoading(false);
    }).catchError((e) {
      isLoading(false);
      toast(e.toString(), print: true);
    });
  }

  void handleEditReview() {
    showWriteReview(true);
    reviewCont.text = yourReview.value.reviewMsg;
    selectedRating(yourReview.value.rating.toDouble());
  }

  void showReview() {
    showWriteReview(false);
  }

  Future<void> deleteReview() async {
    isLoading(true);
    await BookingServiceApis.deleteReview(id: yourReview.value.id).then((value) async {
      log('updateReview: ${value.toJson()}');
      toast(value.message);
      showWriteReview(false);
      hasReview(false);
      reviewCont.text = "";
      selectedRating(0);
      yourReview(EmployeeReviewData());
      isLoading(false);
    }).catchError((e) {
      isLoading(false);
      toast(e.toString(), print: true);
    });
  }
}

Color getRatingBarColor(num starNumber) {
  if (starNumber >= 3.6 || starNumber >= 5) {
    return ratingFirstColor;
  } else if (starNumber >= 3) {
    return ratingSecondColor;
  } else if (starNumber >= 2) {
    return ratingFifthColor;
  } else if (starNumber >= 1) {
    return ratingThirdColor;
  }
  return ratingFourthColor;
}
