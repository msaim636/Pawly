import 'package:flutter/material.dart';
import 'package:pawlly/components/screen_shimmer.dart';
import 'package:pawlly/screens/home/blog/blog_item_component_shimmer.dart';

class BlogListScreenShimmer extends StatelessWidget {
  const BlogListScreenShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      padding: EdgeInsets.only(bottom: 16),
      child: ScreenShimmer(
        shimmerComponent: BlogItemComponentShimmer(),
      ),
    );
  }
}
